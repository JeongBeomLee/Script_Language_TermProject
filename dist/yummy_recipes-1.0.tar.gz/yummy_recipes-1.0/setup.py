from distutils.core import setup

setup(name = 'yummy_recipes',
      version = '1.0',
      py_modules=['yummy_recipes']
      )
